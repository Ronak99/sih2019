<?php

    include 'connection.php';

    $conn = OpenCon(); 
      
    if(isset($_POST["book_btn"])){

        $name = $_POST["name"];
        $source = $_POST["from_field"];
        $destination = $_POST["to_field"];
        $seats = $_POST["seats"];
        $date = $_POST["date"];
        $class = $_POST["class"];
       
        $sql = "INSERT INTO `tickets` (`sno`, `source`, `destination`, `name`, `seats`, `date`, `class`) VALUES (NULL, '$source', '$destination', '$name', '$seats', '$date', '$class');";

        if ($conn->query($sql) === TRUE) {
           
            header('Location: index.php');
            exit; 

        } else {
            echo "Error: " . $sql . "<br>" . $conn->error;
        }
        
        $conn->close();

    }

?>


<html>

    <head>

        <link rel="stylesheet" href="css/index.css">

        <link href="https://fonts.googleapis.com/css?family=Montserrat" rel="stylesheet">
         
        <title>IRCTC Mock Website </title>

    </head>

    <body>


        <div class="titleBar">


            <img src="img/irctc_logo.png" class="irctc_logo">
            

        </div>

        <div class="coverImg" >

            <div class="coverContentContainer">

            <div class="ticketBookingForm">

                <div class='heading'>

                    <span>BOOK</span>
                    <span>YOUR TICKET</span>
                    <img src="img/rail_icon.png">

                </div>

                <div class="form">
                    <form action="index.php" method="POST">
                         <input type="text" name="from_field" placeholder="From*">

                         <input type="text" name="to_field" placeholder="To*">

                         <input type="text" name="name" placeholder="Your Name">

                         <input type="text" name="seats" placeholder="Total seats required">

                         <input type="text" name="date" placeholder="Enter Date">

                         <select name="class">
                             <option value="">All Classes</option>
                             <option value="SL">SLEEPER</option>
                             <option value="">All Classes</option>
                             <option value="">All Classes</option>

                         </select>

                         <input class="book" type="submit" value="BOOK" name="book_btn" onclick="showMessage()">
                </form> 
                </div>

            </div>

            <div class="railways_text">

                <span>Indian Railways</span>
                <span>Safety | Security | Punctuality</span>
                    

            </div>

            </div>

        </div>
        

        <script>

            function showMessage(){
                alert("Ticket succesfully booked");
            }

        </script>

    </body>


</html>