<?php

echo "redirected";

?>