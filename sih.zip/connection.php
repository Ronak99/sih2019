<?php

function OpenCon(){

    $dbhost = "localhost";
    $dbuser = "root";
    $dbpass = "";
    $db = "demo";

    $conn = new mysqli($dbhost, $dbuser, $dbpass, $db) or die("Could'nt connected ".$conn->error);

    return $conn;
}

function CloseCon($conn){

    $conn->close();    

}


?>